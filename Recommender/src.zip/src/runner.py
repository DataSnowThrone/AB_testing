
from src.controller.data_controller import DataController
import datetime

class Runner:
    def __init__(self,spark,env,running_date,hour):
        self.spark = spark
        self.env = env
        self.running_date = running_date
        self.hour = hour

    def run(self):
        env_recsys = f"{self.env}_recsys"
        _DataController = DataController(self.spark, env_recsys,self.env)
        hour=self.hour
        running_date = self.running_date
        date_format_running_date = datetime.datetime.strptime(running_date, "%Y-%m-%d")

        df_hist=_DataController.get_hist_result(date_format_running_date,hour)
        df_global_prediction = _DataController.get_global_pred(date_format_running_date,hour)
        df_user_list_no_history = _DataController.get_user_list_no_history(date_format_running_date)
        df_global= df_user_list_no_history.join(df_global_prediction,['p1_date']).select('p1_date','p1_hour','user_id','product_list')

        df_to_kafka = df_hist
        #df_to_kafka=df_hist.unionByName(df_global)
        # limit the number to write to kafka, will remove later
        #num_record_to_write=100
        #_DataController.write_result_to_kafka(df_to_kafka.limit(num_record_to_write)
        _DataController.write_result_to_kafka(df_to_kafka)
        # num_record_to_write=100000
        # _DataController.write_result_to_kafka(df_to_kafka.limit(num_record_to_write))


