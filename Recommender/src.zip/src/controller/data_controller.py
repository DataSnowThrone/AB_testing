import pyspark.sql.functions as F

class DataController:

    def __init__(self,spark,env_recsys,env):
        self.spark = spark
        self.env = env
        self.env_recsys = env_recsys

    def get_hist_result(self,running_date,hour):
        df = self.spark.read.load(f"gs://{self.env_recsys}/prediction/history_inference")
        # df = df.withColumn("p1_date_str", F.date_format(F.col('p1_date')))
        # df = df.filter(F.col("p1_date") == running_date)
        df = df.filter(f"p1_date =='{running_date}'")
        df = df.filter(f"p1_hour =={hour}")
        return df

    def get_global_pred(self,running_date,hour):
        df = self.spark.read.load(f"gs://{self.env_recsys}/prediction/global_prediction")
        df = df.filter(f"p1_date =='{running_date}'")
        df = df.filter(f"p1_hour =={hour}")
        return df

    def get_user_list_no_history(self,running_date):
        df = self.spark.read.load(f"gs://{self.env_recsys}/prediction/no_history_user_id")
        df = df.filter(f"p1_date =='{running_date}'")
        return df

    def write_result_to_kafka(self,df):
        topic_name=f"{self.env}-slot-item-user"
        print(f"topic name is {topic_name}")
        slot_name = "recommender_user_product"
        pred_kafka_df = df.withColumn('slot_id', F.lit(slot_name))
        ttl_value = 10080
        slot_min_len = 6
        pred_kafka_df = pred_kafka_df.withColumn('ttl', F.lit(ttl_value))
        pred_kafka_df = pred_kafka_df.withColumn("slot_min_len", F.lit(slot_min_len))
        # bootstrap_servers=self.bootstrap_servers
        bootstrap_servers = "broker-0.kafka.internal.data.ztore.com:29092,\
                                     broker-1.kafka.internal.data.ztore.com:29092,\
                                     broker-2.kafka.internal.data.ztore.com:29092"
        pred_kafka_df_sel = pred_kafka_df
        pred_kafka_df_sel = pred_kafka_df_sel.select(F.to_json(F.struct('user_id', "slot_id")).alias('user_info'),
                                                     F.to_json(F.struct('user_id', "slot_id", "slot_min_len",
                                                                        'product_list', 'ttl')).alias('info'))
        write_df = pred_kafka_df_sel.selectExpr("CAST(user_info AS STRING) as key", "CAST(info AS STRING) as value")
        write_df.write.format("kafka").option("kafka.bootstrap.servers", bootstrap_servers).option("topic",
                                                                                                   topic_name).save()

